const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" }));

app.post("/api/upload", (req, res) => {
  const { name, data } = req.body;

  if (!name || !data) {
    return res.status(400).json({ error: "Dados inválidos" });
  }

  db.prepare(
    "INSERT INTO datasets (name, data) VALUES (?, ?)"
  ).run(name, JSON.stringify(data));

  res.json({ success: true });
});

app.get("/api/datasets", (req, res) => {
  const rows = db.prepare(
    "SELECT id, name, created_at FROM datasets"
  ).all();

  res.json(rows);
});

app.get("/api/datasets/:id", (req, res) => {
  const row = db.prepare(
    "SELECT * FROM datasets WHERE id = ?"
  ).get(req.params.id);

  if (!row) return res.status(404).json({ error: "Não encontrado" });

  row.data = JSON.parse(row.data);
  res.json(row);
});

app.listen(3333, () => {
  console.log("🚀 Backend rodando em http://localhost:3333");
});
